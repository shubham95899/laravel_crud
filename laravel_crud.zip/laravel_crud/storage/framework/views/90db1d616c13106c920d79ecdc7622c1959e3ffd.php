<html>
  <html lang="en">
  <head>
  	<meta charset="UTF-8">
     <meta name="viewport"
     content="width=device-width,user-scalable=no,initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
     <meta http-equiv="X-UA-Compatible" content="ie=edge">
     <title>Laravel Crud Application</title>
     <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
  </head>
     

  <body class="bg-light">
     <div class="p-3 mb-2 bg-dark text-white">
     	<div class="container">
     		<div class="h3">Laravel Crud Application</div>
     	</div>
     </div>
     <div class="container">
        <div class="row">
           <div class="col-md-12 text-right mb-3">
             <a href="<?php echo e(url('articles/add')); ?>" class="btn btn-primary">ADD</a>
           </div>
           <?php if(Session::has('msg')): ?>
           <div>
              <div class="alert alert-success"><?php echo e(Session::get('msg')); ?></div>
           </div>
          <?php endif; ?>

           <?php if(Session::has('errorMsg')): ?>
           <div>
              <div class="alert alert-danger"><?php echo e(Session::get('errorMsg')); ?></div>
           </div>
          <?php endif; ?>

        </div>
       
        <div class="card">
        	<div class="card-header"><h6>Articles / List</h6></div>
        	<div class="card-body">
        		<table class="table">
        			<thead class="thead-dark">
        				<tr>
                            <th>ID</th>
                            <th>First name</th>
                            <th>Last Name</th>
                            <th>Phone No.</th>
                            <th>Email Id</th>
                            <th>DOB</th>
                            <th>Salary</th>
                            <th>Edit</th>
                            <th>Delete</th>
        				</tr>
        			</thead>
        			<?php if($articles): ?>
        			<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        			<tr>
                       <td><?php echo e($article->id); ?></td>
                       <td><?php echo e($article->first_name); ?></td>
                       <td><?php echo e($article->last_name); ?></td>
                       <td><?php echo e($article->phone_no); ?></td>
                       <td><?php echo e($article->email); ?></td>
                       <td><?php echo e($article->dob); ?></td>
                       <td><?php echo e($article->salary); ?></td>
                       <td><a href="<?php echo e(url('articles/edit/'.$article->id)); ?>" class="btn btn-primary">Edit</a></td>
                       <td><a href="#" onclick="deleteArticle(<?php echo e($article->id); ?>);" class="btn btn-danger">Delete</a></td>
        			</tr>
        			     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        			<?php else: ?>
        			<tr>
                        <td colspan="6">Data not added Yet</td>
        			</tr>
        			<?php endif; ?>
        		</table>
        	</div>
        </div>
    
  </body>
  <script type="text/javascript">
  function deleteArticle(id)
  {
    if(confirm('Are you sure want to delete?'))
    {
      window.location.href='<?php echo e(url('articles/delete')); ?>/' + id;
    }
  }

</script>
</html>

<?php /**PATH C:\Users\shubham\Desktop\laravel_crud\resources\views/list.blade.php ENDPATH**/ ?>