<html>
  <html lang="en">
  <head>
     <meta charset="UTF-8">
     <meta name="viewport"
     content="width=device-width,user-scalable=no,initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
     <meta http-equiv="X-UA-Compatible" content="ie=edge">
     <title>Laravel Crud Application</title>
     <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>"
  </head>
  <body class="bg-light">
     <div class="p-3 mb-2 bg-dark text-white">
     	<div class="container">
     		<div class="h3">Laravel Crud Application</div>
     	</div>
     </div>
     <div class="container">
        <div class="row">
           <div class="col-md-12 text-right mb-3">
             <a href="<?php echo e(url('articles')); ?>" class="btn btn-primary">Back</a>
           </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header"><h5>Article / Edit</h5></div>
              <div class="card-body">
                <form action="<?php echo e(url('articles/edit/'.$article->id)); ?>" method="post" name="addArticles" id="addArticle">
                  <?php echo csrf_field(); ?>
             <div class="form-group">
                  <lable for"">First Name</lable>
                  <input type="text" name="first_name" id="first_name" value="<?php echo e(old('first_name',$article->first_name)); ?>" class="form-control
                  <?php echo e(($errors->any() && $errors->first('first_name')) ? 'is-invalid' : ''); ?>">
                     <?php if($errors->any()): ?>
                          <p class="invalid-feedback"><?php echo e($errors->first('first_name')); ?></p>
                     <?php endif; ?>

             </div>
             <div class="form-group">
                  <lable for"">Last Name</lable>
                  <input type="text" name="last_name" id="last_name" value="<?php echo e(old('last_name',$article->last_name)); ?>" class="form-control
                 <?php echo e(($errors->any() && $errors->first('last_name')) ? 'is-invalid' : ''); ?>">

                   <?php if($errors->any()): ?>
                          <p class="invalid-feedback"><?php echo e($errors->first('last_name')); ?></p>
                     <?php endif; ?>
             </div>
             <div class="form-group">
                  <lable for"">Phone No.</lable>
                  <input type="int" name="phone_no" id="phone_no" value="<?php echo e(old('phone_no',$article->phone_no)); ?>" class="form-control
             <?php echo e(($errors->any() && $errors->first('phone_no')) ? 'is-invalid' : ''); ?>">

                   <?php if($errors->any()): ?>
                          <p class="invalid-feedback"><?php echo e($errors->first('phone_no')); ?></p>
                     <?php endif; ?>
             </div>
             <div class="form-group">
                  <lable for"">Email</lable>
                  <input type="email" name="email" id="email" value="<?php echo e(old('email',$article->email)); ?>" class="form-control
                  <?php echo e(($errors->any() && $errors->first('email')) ? 'is-invalid' : ''); ?>">

                   <?php if($errors->any()): ?>
                          <p class="invalid-feedback"><?php echo e($errors->first('email')); ?></p>
                     <?php endif; ?>
             </div>
             <div class="form-group">
                  <lable for"">Date Of Birth</lable>
                  <input type="int" name="dob" id="dob" value="<?php echo e(old('dob',$article->dob)); ?>" class="form-control
                   <?php echo e(($errors->any() && $errors->first('dob')) ? 'is-invalid' : ''); ?>">
                   <?php if($errors->any()): ?>
                          <p class="invalid-feedback"><?php echo e($errors->first('dob')); ?></p>
                     <?php endif; ?>
             </div>
             <div class="form-group">
                  <lable for"">salary</lable>
                  <input type="int" name="salary" id="salary" value="<?php echo e(old('salary',$article->salary)); ?>" class="form-control
                  <?php echo e(($errors->any() && $errors->first('salary')) ? 'is-invalid' : ''); ?>">
                   <?php if($errors->any()): ?>
                          <p class="invalid-feedback"><?php echo e($errors->first('salary')); ?></p>
                     <?php endif; ?>
             </div>
             <div>
                 <button type="submit" name="submit" class="btn btn-primary">Update Article</button>
             </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
  </body>
</html><?php /**PATH C:\Users\shubham\Desktop\laravel_crud\resources\views/edit.blade.php ENDPATH**/ ?>