<?php

namespace App\Http\Controllers;


use App\Article;
use Illuminate\Http\Request;
use Illuminate\support\Facades\validator;
use DB;


class ArticleController extends Controller
{
    function show(){
    	$articles = DB::table('articles')->orderBy('id','DESC')->get();
    	return view ('list')->with(compact('articles'));
    }
    function addArticle()
    {
    	return view ('add');
    }
    function saveArticle(Request $request)
    {
       $validator = Validator::make($request->all(),[
             'first_name' => 'required',
             'last_name' => 'required',
             'phone_no' => 'required|max:10',
             'email' => 'required|email',
             'dob' => 'required',
             'salary'=> 'required'
       ]);      
       if ($validator->passes()){
       $article = new Article;
       $article->first_name = $request->first_name;
       $article->last_name = $request->last_name;
       $article->phone_no = $request->phone_no;
       $article->email = $request->email;
       $article->dob = $request->dob;
       $article->salary = $request->salary;
       $article->save();

       $request->session()->flash('msg','Article Saved Successfully');
       return redirect ('articles');
      
       }else
       {
       	return redirect('articles/add')->withErrors($validator)->withinput();
       	//return with error
       }
    }
    function editArticle($id, Request $request)
    {
    	$article = Article::where('id',$id)->first();
    	if(!$article)
    	{
    		$request->session()->flash('errorMsg','Record Not Found');
    		return redirect('articles');
    	}
    	return view('edit')->with(compact('article'));
    }
    function updateArticle($id, Request $request)
    {
    	$validator = Validator::make($request->all(),[
             'first_name' => 'required',
             'last_name' => 'required',
             'phone_no' => 'required|max:10',
             'email' => 'required|email',
             'dob' => 'required',
             'salary'=> 'required'
       ]);      
       if ($validator->passes()){
       $article =Article::find($id);
       $article->first_name = $request->first_name;
       $article->last_name = $request->last_name;
       $article->phone_no = $request->phone_no;
       $article->email = $request->email;
       $article->dob = $request->dob;
       $article->salary = $request->salary;
       $article->save();

       $request->session()->flash('msg','Data Updated Successfully');
       return redirect ('articles');
      
       }else
       {
       	return redirect('articles/edit'.$id)->withErrors($validator)->withinput();
       	//return with error
       }
    }


    function deleteArticle($id, Request $request)
    {
    	$article = Article::where('id',$id)->first();
    	if(!$article)
    	{
    		$request->session()->flash('errorMsg','Record Not Found.');
    		return redirect('articles');
    	
    	 }

    	 Article::where('id',$id)->delete();
    	 $request->session()->flash('msg','Data has Been Deleted Successfully ');
    	 return redirect('articles');
}

    public function create(request $request)
    {
    	$articles = new article();

    	$articles->first_name = $request->input('first_name');
    	$articles->last_name = $request->input('last_name');
        $articles->phone_no = $request->input('phone_no');
        $articles->email = $request->input('email');
        $articles->dob = $request->input('dob');
        $articles->salary = $request->input('salary');

        $articles->save();
        return response()->json($articles);

    }

}