<html>
  <html lang="en">
  <head>
  	<meta charset="UTF-8">
     <meta name="viewport"
     content="width=device-width,user-scalable=no,initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
     <meta http-equiv="X-UA-Compatible" content="ie=edge">
     <title>Laravel Crud Application</title>
     <link rel="stylesheet" href="{{asset('assets/css/bootstrap.css')}}">
  </head>
     

  <body class="bg-light">
     <div class="p-3 mb-2 bg-dark text-white">
     	<div class="container">
     		<div class="h3">Laravel Crud Application</div>
     	</div>
     </div>
     <div class="container">
        <div class="row">
           <div class="col-md-12 text-right mb-3">
             <a href="{{url('articles/add')}}" class="btn btn-primary">ADD</a>
           </div>
           @if (Session::has('msg'))
           <div>
              <div class="alert alert-success">{{Session::get('msg')}}</div>
           </div>
          @endif

           @if (Session::has('errorMsg'))
           <div>
              <div class="alert alert-danger">{{Session::get('errorMsg')}}</div>
           </div>
          @endif

        </div>
       
        <div class="card">
        	<div class="card-header"><h6>Articles / List</h6></div>
        	<div class="card-body">
        		<table class="table">
        			<thead class="thead-dark">
        				<tr>
                            <th>ID</th>
                            <th>First name</th>
                            <th>Last Name</th>
                            <th>Phone No.</th>
                            <th>Email Id</th>
                            <th>DOB</th>
                            <th>Salary</th>
                            <th>Edit</th>
                            <th>Delete</th>
        				</tr>
        			</thead>
        			@if($articles)
        			@foreach($articles as $article)
        			<tr>
                       <td>{{$article->id}}</td>
                       <td>{{$article->first_name}}</td>
                       <td>{{$article->last_name}}</td>
                       <td>{{$article->phone_no}}</td>
                       <td>{{$article->email}}</td>
                       <td>{{$article->dob}}</td>
                       <td>{{$article->salary}}</td>
                       <td><a href="{{url('articles/edit/'.$article->id)}}" class="btn btn-primary">Edit</a></td>
                       <td><a href="#" onclick="deleteArticle({{$article->id}});" class="btn btn-danger">Delete</a></td>
        			</tr>
        			     @endforeach
        			@else
        			<tr>
                        <td colspan="6">Data not added Yet</td>
        			</tr>
        			@endif
        		</table>
        	</div>
        </div>
    
  </body>
  <script type="text/javascript">
  function deleteArticle(id)
  {
    if(confirm('Are you sure want to delete?'))
    {
      window.location.href='{{url('articles/delete')}}/' + id;
    }
  }

</script>
</html>

